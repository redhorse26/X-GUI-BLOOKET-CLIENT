

  function openSilentTab(customId, targetUrl, initialData) {
    chrome.runtime.sendMessage({
      type: "CREATE_TAB",
      id: customId,
      url: targetUrl,
      data: initialData
    });
  }

  function sendMessageToTab(targetId, dataPayload) {
    chrome.runtime.sendMessage({
      target: "TO_OPENED_TAB",
      id: targetId,
      data: dataPayload
    });
  }

  function onCommunicationReceived(fromId, data) {
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "COMMUNICATION") {
      onCommunicationReceived(msg.fromId, msg.data);
    }
  });
  gid = prompt("Game ID:");
  if(gid){
    openSilentTab("blooket-tst", "https://play.blooket.com/play?id="+gid, {gameId: gid});
  }